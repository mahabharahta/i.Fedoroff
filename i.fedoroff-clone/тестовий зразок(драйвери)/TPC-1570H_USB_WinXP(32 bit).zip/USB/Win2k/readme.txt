Microsoft Windows 2000 Support for USB 2.0
==========================================


Table of Contents
-----------------
1. Introduction
2. Contents of this CD
3. Installation Directions
4. Installation Instructions for Network Install


---------------
1. Introduction
---------------
The contents on this CD will allow OEMs and System Builders to incorporate USB 2.0 support for EHCI Host Controllers on the Microsoft(r) Windows(r) 2000 operating system (with Service Pack 2).


1.1 USB 2.0 EHCI Host Controllers Supported
-------------------------------------------
The drivers provided on this CD have been tested with the NEC USB 2.0 host controller and the Intel EHCI Host Controller. The hardware IDs of the USB 2.0 host controllers supported by the provided solution are as follows:
	PCI\VEN_1033&DEV_00E0&REV_01
	PCI\VEN_1033&DEV_00E0&REV_02
	PCI\VEN_8086&DEV_24CD

The driver will not install on any other EHCI controllers with hardware IDs different from the ones stated above. Microsoft�s plans regarding support of additional EHCI controllers can be found on http://www.microsoft.com/hwdev/bus/usb.  


1.2 USB 2.0 Hub support
-----------------------
USB 2.0 hubs are supported by this package.



----------------------
2. Contents of this CD
----------------------
This CD contains the USB 2.0 EHCI package necessary to support USB EHCI controllers and USB 2.0 hubs.

The USB 2.0 EHCI package consists of the following files:
	USBHUB20.SYS
	USBPORT.SYS
	USBEHCI.SYS
	HCCOIN.DLL
	USB2.INF
	USB2.CAT

The INF file is responsible for loading the USBEHCI.SYS host controller miniport, the port driver and a hub20 driver on a Windows 2000 system. The host controller coinstaller (HCCOIN.DLL) is also registered and is responsible for ensuring proper installation of the USB 2.0 driver stack.

Unlike the Windows XP release, a QFE package is not required for the Windows 2000 release as no Windows 2000 existing files are being replaced or updated.



--------------------------
3. Installation Directions 
--------------------------
Install the USB 2.0 EHCI package using Plug and Play INF installation procedures. 



------------------------------------------------
4. Installation Instructions for Network Install
------------------------------------------------

Copy the files from the CD in "EHCI Package" directory to i386\$OEM$\$1\PnPDrvrs\USB20

Include the USB 2.0 directory in your OEMPnPDriversPath in unattend.txt.  For example:

OEMPnPDriversPath = "PnPDrvrs\USB20"


If you have any issues, please work with your Microsoft OEM PM or Technical Account Manager (TAM) to have them addressed as soon as possible.


Thanks,

Windows USB Team

(c) 2001 Microsoft Corporation. All rights reserved.

The information contained in this document represents the current view of Microsoft Corporation on the issues discussed as of the date of publication. Because Microsoft must respond to changing market conditions, it should not be interpreted to be a commitment on the part of Microsoft, and Microsoft cannot guarantee the accuracy of any information presented. This document is for informational purposes only. MICROSOFT MAKES NO WARRANTIES, EXPRESS OR IMPLIED, IN THIS DOCUMENT.

Microsoft, Windows, and Windows NT are trademarks or registered trademarks of Microsoft Corporation in the United States and/or other countries. Other product and company names mentioned herein may be the trademarks of their respective owners.



 