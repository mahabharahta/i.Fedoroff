Windows 2000 USB2.0 Driver Installation Guide
====================================
Introduction: 
-----------------
This driver only works with Intel ICH4 chipset & Windows 2000. 

Installation: 
-----------------
Note: You must go through all below procedures to complete the driver installation. 
 
1.  Click Windows [Start], then move the mouse to stay on [Settings].
2.  Click [Control Panel].
3. Double Click [System].
4. Click [Hardware] tab.
5. Click [Device Manager].
6. Right Click [Universal Serial Bus(USB) Controller] under [Other Devices], 
then click [Property].
7. Click [Driver] tab.
8. Click [Update Driver].
9. Click [Next].
10. Choose [Search for a suitable driver for my device].
11. Click [Next].
12. Choose [Specify a location] under "Optional search location".
13. Click [Next].
14. Click [Browse] to specify the file path where the driver is, e.g. 
"X:\...\2K\EHCI Package\".
(X:\...\ is the directory where you put the Win 2000 driver.)
15. Click [Next].
16. Click [Finish].

