.\" $XFree86: xc/programs/Xserver/hw/xfree86/input/penmount/penmount.cpp,v 1.2 2000/12/11 20:18:55 dawes Exp $ 
.TH PENNMOUNT __drivermansuffix__ "Version 4.0.2"  "XFree86"
.SH NAME
penmount \- PenMount input driver
.SH SYNOPSIS
.B "Section ""InputDevice"""
.br
.BI "  Identifier """ idevname """"
.br
.B  "  Driver ""penmount"""
.br
.BI "  Option ""Device""   """ devpath """"
.br
\ \ ...
.br
.B EndSection
.SH DESCRIPTION
.B penmount 
is an XFree86 input driver for PenMount devices...
.PP
The
.B penmount
driver functions as a pointer input device, and may be used as the
X server's core pointer.
THIS MAN PAGE NEEDS TO BE FILLED IN.
.SH SUPPORTED HARDWARE
What is supported...
.SH CONFIGURATION DETAILS
Please refer to XF86Config(__filemansuffix__) for general configuration
details and for options that can be used with all input drivers.  This
section only covers configuration details specific to this driver.
.PP
Config details...
.SH "SEE ALSO"
XFree86(1), XF86Config(__filemansuffix__), xf86config(1), Xserver(1), X(__miscmansuffix__).
.SH AUTHORS
Authors include...
