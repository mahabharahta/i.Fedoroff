Copyright (c) By Salt International Corp. All rights reserved. 

PENMOUNT WINDOWS NT4 DRIVER INSTALLATION

This driver supports Windows NT version4.0 . The detailed contents of this driver is list below:
SETUP.LID
SETUP.INS
SETUP.INI
SETUP.EXE 
SETUP.BMP
README.TXT 
OS.DAT
LICENSE.TXT
LAYOUT.BIN
INST32I.EX
DATA1.CAB
DATA.TAG
USER1.CAB
SYS1.CAB
_SETUP.DLL
ISDEL.EXE
LANG.DAT

There are several functions in PenMount Windows NT4 driver :

1. PenMount monitor: After PenMount Windows NT4 driver installed, the PenMount monitor will appear on the menu bar of the system. It is easy for user to call other PenMount utilities or functions on line.

2. Auto-detecting serial port: When install PenMount Windows NT4 drivers, the system automatically detects the COM port, IRQ and Base address that touch screen connected to. 

3. Beep sound on/off

4. Initialization PenMount controller: This makes sure the PenMount controller chipset initialized properly.

5. Hiding cursor: For some special application programs, cursor can be hidden.

6. Cursor offset: For some applications, user can offset the cursor.

7. Right button selectable: This emulates mouse right button function on touching.

8. Double click speed and width adjustment

9. Drawing test

10. Uninstall utilities: Use this to remove PenMount Windows NT4 driver from system


PenMount Windows NT4 driver installation

To install the software to your computer, you must have Windows NT4 system running. If you have an older version PenMount Windows NT4 driver installed in your system, please remove it first.   

Follow the steps below to install the PenMount Windows NT driver.  
1. Insert PenMount Windows NT4 driver diskette to your FDD. From the "Start" menu, select "Run". There is one entry "setup.exe" in PenMount Windows NT4 driver .  Use browse to find it or type in "A:\setup.exe" to execute it.

2. The screen displays PenMount Logo and SETUP utility, then show the installation wizard and start to copy "PenMount Windows NT4 Driver Installation". Select "Next".

3. The next screens is "Software License Agreement", select "Yes".

4. The next screens is "Information", select "Next".

5. The next screen is "Choose Destination Location", it is for Setup installing PenMount Utilities in the folder: C:\Program Files\PenMount\NT, select "Next" or modify the folder name you like to use.

6. The next screen is "Select Program Folder, the default is set at "PenMount Utilities", select "Next" or change it.

7. After selecting well, the screen is showing "Start Copying Files", select "Next" for starting copy files to system.

8. The screen now is "Setup Complete", and show "PenMount Control Panel". Set  'Configure' now. Use "DETECT" icon to choose the com port and IRQ no.

9. System will ask you to reboot. Reboot the system to completely install PenMount NT4 driver. After rebooting, PenMount Windows NT4 driver is installed well. The 'PenMount Utilities' now is in the 'Programs', you could have the 'PenMount Monitor' appeared in the menu bar for easily selecting PenMount funcitons.

10. Do 'Calibrate' now, from "PenMount Control Panel" of 'PenMount Utilities'
in 'Programs.

Function description:
--- "PenMount Control Panel": This utility is located at "PenMount Utilities" of "Programs", there are following functions: 
- Configure: there is two information on it, one is Hardware information:  It  the 
PenMount controller type, DMC9000.   Baud Rate:  For DMC9000 baud rate is fixed at 19200 baud.  Status:
   "Detect" icon is the auto-detecting key for detecting COM port, IRQ number, based address.   Choose the COM port number or key in the correct IRQ no and base address if choose 'User defined'. 

The other one is Serial Port Status: user could use keyboard to key-in the correct com port information for PenMount driver 


- Calibrate: There are two functions on it, "Initial" and "Calibrate". "Initial" is for reset PenMount controller chipset.

"Calibrate": click it and follow the instructions to do calibration by touching mid-top, mid-right, mid-bottom and mid-left.  After calibration done, it is suggested to go to Draw to test the result.

- Setting:  There are several functions on this setting:
a. Misc. Option: "Right Click Button" and "Beep Sound"
b. Cursor: "Hide Cursor" and "Cursor Offset"
c. Double Click : "Double Click Area", "Double Click Speed" and "Test" area

- Draw: Test or refer to PenMount touch screen operation

- About: PenMount information

--- PenMount Monitor: this is located at "PenMount Utilities" of "Programs", it will appear a monitor icon on menu bar of the system.  There are "Initialize", "Right Click", 'Hide Cursor", "Cursor Offset", "Beep Sound" and "Exit" functions on it. This is for user easily choose the needed PenMount utilities.

--- PenMount Uninstall: to remove PenMount Windows NT4 driver from system

--- ReadMe: this file.




